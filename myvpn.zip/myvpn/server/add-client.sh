#!/usr/bin/env bash
# Kullanım: sudo bash add-client.sh <istemci-adi>
set -euo pipefail
NAME=${1:?"istemci adı verin, örn: telefonum"}
cd /etc/wireguard
umask 077
N=$(( $(grep -c '^\[Peer\]' wg0.conf) + 2 ))
CIP="10.8.0.$N"
wg genkey | tee "client-$NAME.key" | wg pubkey > "client-$NAME.pub"

cat > "client-$NAME.conf" <<CONF
[Interface]
PrivateKey = $(cat client-$NAME.key)
Address = $CIP/32
DNS = 1.1.1.1

[Peer]
PublicKey = $(cat server.pub)
Endpoint = $(cat endpoint)
AllowedIPs = 0.0.0.0/0, ::/0
PersistentKeepalive = 25
CONF

wg set wg0 peer "$(cat client-$NAME.pub)" allowed-ips "$CIP/32"
cat >> wg0.conf <<CONF

[Peer]
# $NAME
PublicKey = $(cat client-$NAME.pub)
AllowedIPs = $CIP/32
CONF

echo "=== /etc/wireguard/client-$NAME.conf (uygulamaya yapıştırın) ==="
cat "client-$NAME.conf"
qrencode -t ansiutf8 < "client-$NAME.conf"
