#!/usr/bin/env bash
# Ubuntu 22.04/24.04 VPS üzerinde root olarak çalıştırın: sudo bash setup-wireguard.sh
set -euo pipefail
[ "$EUID" -eq 0 ] || { echo "root olarak çalıştırın"; exit 1; }

apt update && apt install -y wireguard qrencode iptables curl
PORT=51820
IFACE=$(ip route show default | awk '/default/ {print $5; exit}')
PUBIP=$(curl -4 -s https://ifconfig.me)

umask 077
mkdir -p /etc/wireguard
wg genkey | tee /etc/wireguard/server.key | wg pubkey > /etc/wireguard/server.pub
echo "$PUBIP:$PORT" > /etc/wireguard/endpoint

cat > /etc/wireguard/wg0.conf <<CONF
[Interface]
Address = 10.8.0.1/24
ListenPort = $PORT
PrivateKey = $(cat /etc/wireguard/server.key)
PostUp = iptables -A FORWARD -i wg0 -j ACCEPT; iptables -A FORWARD -o wg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o $IFACE -j MASQUERADE
PostDown = iptables -D FORWARD -i wg0 -j ACCEPT; iptables -D FORWARD -o wg0 -j ACCEPT; iptables -t nat -D POSTROUTING -o $IFACE -j MASQUERADE
CONF

echo "net.ipv4.ip_forward=1" > /etc/sysctl.d/99-wireguard.conf
sysctl --system >/dev/null
command -v ufw >/dev/null && ufw allow $PORT/udp || true
systemctl enable --now wg-quick@wg0

echo "Kurulum tamam. Endpoint: $PUBIP:$PORT"
echo "Sonraki adım: bash add-client.sh telefonum"
