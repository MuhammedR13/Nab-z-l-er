package com.example.myvpn

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.StringReader

class MainActivity : ComponentActivity() {
    private lateinit var backend: GoBackend
    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView
    private lateinit var spinner: Spinner
    private lateinit var toggle: Button
    private lateinit var addBtn: Button
    private lateinit var delBtn: Button
    private val servers = mutableListOf<Pair<String, String>>() // ad, yapılandırma
    private var connected = false

    private val tunnel = object : Tunnel {
        override fun getName() = "myvpn"
        override fun onStateChange(newState: Tunnel.State) {
            runOnUiThread { render(newState == Tunnel.State.UP) }
        }
    }

    private val permission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) setState(Tunnel.State.UP)
        else status.text = "VPN izni reddedildi"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        backend = GoBackend(applicationContext)
        prefs = getSharedPreferences("vpn", Context.MODE_PRIVATE)
        loadServers()

        status = TextView(this).apply { text = "Bağlı değil"; textSize = 26f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0, 0, 0, 48) }
        spinner = Spinner(this)
        toggle = Button(this).apply { text = "Bağlan"; setOnClickListener { onToggle() } }
        addBtn = Button(this).apply { text = "Sunucu ekle"; setOnClickListener { showAddDialog() } }
        delBtn = Button(this).apply { text = "Seçili sunucuyu sil"; setOnClickListener { deleteSelected() } }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 120, 48, 48)
            addView(status); addView(spinner); addView(toggle); addView(addBtn); addView(delBtn)
        })
        refreshSpinner()
    }

    private fun render(up: Boolean) {
        connected = up
        status.text = if (up) "Bağlı: ${selectedName()}" else "Bağlı değil"
        toggle.text = if (up) "Bağlantıyı kes" else "Bağlan"
        spinner.isEnabled = !up; addBtn.isEnabled = !up; delBtn.isEnabled = !up
    }

    private fun selectedName() = servers.getOrNull(spinner.selectedItemPosition)?.first ?: ""

    private fun onToggle() {
        if (connected) { setState(Tunnel.State.DOWN); return }
        if (servers.isEmpty()) { status.text = "Önce sunucu ekleyin"; return }
        val intent = GoBackend.VpnService.prepare(this)
        if (intent != null) permission.launch(intent) else setState(Tunnel.State.UP)
    }

    private fun setState(state: Tunnel.State) {
        val conf = servers.getOrNull(spinner.selectedItemPosition)?.second ?: return
        Thread {
            try {
                backend.setState(tunnel, state, Config.parse(BufferedReader(StringReader(conf))))
            } catch (e: Exception) {
                runOnUiThread { status.text = "Hata: ${e.message}" }
            }
        }.start()
    }

    private fun showAddDialog() {
        val name = EditText(this).apply { hint = "Sunucu adı (örn: Almanya)" }
        val conf = EditText(this).apply {
            hint = "Yapılandırma (.conf içeriği)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 8; gravity = Gravity.TOP
            val clip = (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .primaryClip?.getItemAt(0)?.text?.toString()
            if (clip != null && clip.contains("[Interface]")) setText(clip) // panodan otomatik doldur
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 0); addView(name); addView(conf) }
        AlertDialog.Builder(this).setTitle("Sunucu ekle").setView(box)
            .setPositiveButton("Kaydet") { _, _ ->
                try {
                    Config.parse(BufferedReader(StringReader(conf.text.toString()))) // geçerli mi?
                    servers.add(name.text.toString().ifBlank { "Sunucu ${servers.size + 1}" } to conf.text.toString())
                    saveServers(); refreshSpinner()
                } catch (e: Exception) { status.text = "Geçersiz yapılandırma: ${e.message}" }
            }
            .setNegativeButton("İptal", null).show()
    }

    private fun deleteSelected() {
        val i = spinner.selectedItemPosition
        if (i in servers.indices) { servers.removeAt(i); saveServers(); refreshSpinner() }
    }

    private fun refreshSpinner() {
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, servers.map { it.first })
    }

    private fun loadServers() {
        servers.clear()
        val arr = JSONArray(prefs.getString("servers", "[]"))
        for (i in 0 until arr.length()) arr.getJSONObject(i).let { servers.add(it.getString("n") to it.getString("c")) }
    }

    private fun saveServers() {
        val arr = JSONArray()
        servers.forEach { arr.put(JSONObject().put("n", it.first).put("c", it.second)) }
        prefs.edit().putString("servers", arr.toString()).apply()
    }
}
