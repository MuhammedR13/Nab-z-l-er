# MyVPN
## 1. Sunucu (VPS, Ubuntu 22.04/24.04; UDP 51820 açık olmalı)
    sudo bash setup-wireguard.sh
    sudo bash add-client.sh telefonum     # .conf + QR üretir
## 2. İstemci
- Hızlı yol: resmi WireGuard uygulaması + QR kod.
- Kendi uygulamanız: android/ klasörünü Android Studio ile açın, çalıştırın,
  add-client.sh çıktısındaki yapılandırmayı uygulamaya yapıştırıp "Bağlan"a basın.
## 3. Doğrulama
Bağlıyken tarayıcıdan "my ip" sorgulayın: sunucunuzun IP'si görünmeli.
