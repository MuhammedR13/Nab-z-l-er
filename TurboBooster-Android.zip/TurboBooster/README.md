# TurboBooster — Android Oyun Yardımcısı

Gerçek, çalışan bir Android Studio projesi. Kotlin + Jetpack Compose ile yazıldı.

## Nasıl açılır
1. Android Studio'yu aç → **Open** → bu klasörü (`TurboBooster/`) seç.
2. Gradle senkronizasyonunun bitmesini bekle (internet gerekir, bağımlılıklar indirilecek).
3. Bir cihaz/emülatör seç → **Run** (▶) tuşuna bas.

Terminalden derlemek istersen (Android SDK kurulu olmalı):
```
./gradlew assembleDebug
```
APK çıktısı: `app/build/outputs/apk/debug/app-debug.apk`

## Uygulama ne yapar (dürüstçe)

**Gerçekten yaptıkları:**
- RAM, pil, CPU çekirdek bilgisini canlı okur (`ActivityManager`, `BatteryManager`).
- "Hızlandır" butonu: yakın zamanda kullanılmış arka plan uygulamalarının
  önbellek süreçlerini `killBackgroundProcesses()` ile sonlandırmayı **dener**
  ve anlık boşalan RAM miktarını gösterir.
- Oyun Modu: gerçek bir `WakeLock` ile ekranın kilitlenmesini engeller,
  bildirim erişim izniyle Rahatsız Etme (DND) modunu açıp kapatır.
- Uygulama listesi: son 12 saatte kullanılan uygulamaları gösterir, tek
  tıkla arka plan sürecini kapatmayı dener veya Ayarlar'daki "Uygulama
  Bilgisi" ekranına yönlendirerek elle "Zorla Durdur" yapmanı sağlar.

**Bilerek yapmadıkları (ve neden):**
- "FPS'i %XX artırır" gibi sahte sayılar göstermiyor. Android güvenlik
  mimarisi (sandbox) yüzünden hiçbir normal uygulama başka bir uygulamanın
  GPU/CPU performansını veya oyunun kare hızını gerçekten kontrol edemez;
  root olmadan bu teknik olarak mümkün değil.
- Android 5.1'den beri üçüncü parti uygulamalar başka uygulamaların canlı
  çalışan süreç listesini göremez (gizlilik kısıtlaması). Bu yüzden
  "şu an çalışan uygulamalar" yerine dürüstçe "son kullanılan uygulamalar"
  listesi gösteriyoruz (Kullanım Erişimi izniyle).
- Başka bir uygulamayı tam olarak "zorla durdurmak" sistem izni gerektirir;
  normal uygulamalar bunu otomatik yapamaz, bu yüzden kullanıcıyı ilgili
  Ayarlar ekranına yönlendiriyoruz.

## İstenen izinler ve nedenleri
| İzin | Neden |
|---|---|
| `KILL_BACKGROUND_PROCESSES` | Arka plandaki uygulama süreçlerini sonlandırmayı dener |
| `WAKE_LOCK` | Oyun Modu'nda ekranın kilitlenmesini engeller |
| `ACCESS_NOTIFICATION_POLICY` | Rahatsız Etme modunu açıp kapatabilmek için |
| `PACKAGE_USAGE_STATS` (Ayarlar'dan verilir) | Son kullanılan uygulamaları görmek için |
| `QUERY_ALL_PACKAGES` | Yüklü uygulama etiketlerini (isim/ikon) okuyabilmek için |
| `FOREGROUND_SERVICE` | Oyun Modu servisinin arka planda güvenilir çalışması için |

## Gerçekçi beklenti
Bu tür bir uygulamanın oyun performansına katkısı; bildirim kesintilerini
azaltmak, gereksiz arka plan senkronizasyonunu durdurmak ve anlık RAM
baskısını hafifletmekle sınırlıdır. Cihazın ısınması, GPU sürücüsü ve donanım
sınırları gibi asıl FPS belirleyicilerini bir uygulama değiştiremez.
