package com.turbo.booster.ui.theme

import androidx.compose.ui.graphics.Color

val BoostGreen = Color(0xFF00E676)
val DarkBg = Color(0xFF0E1116)
val CardBg = Color(0xFF1A1F27)
val AccentOrange = Color(0xFFFF6D3A)
val TextPrimary = Color(0xFFF5F7FA)
val TextSecondary = Color(0xFF9AA4B2)
val DangerRed = Color(0xFFFF5252)
