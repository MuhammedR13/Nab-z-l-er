package com.turbo.booster

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.Settings

data class AppEntry(
    val packageName: String,
    val label: String,
    val lastUsedMillis: Long,
    val isSystemApp: Boolean
)

object AppUsageUtils {

    /**
     * Kullanım İzleme (Usage Access) izninin verilip verilmediğini kontrol eder.
     * Bu izin, Android'in gizlilik kısıtlamaları nedeniyle sadece kullanıcının
     * Ayarlar'dan elle vermesiyle açılabilir; kodla otomatik açılamaz.
     */
    fun hasUsageAccess(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun openUsageAccessSettings(context: Context) {
        val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(intent)
    }

    /**
     * Son 12 saat içinde kullanılan, kullanıcı tarafından yüklenmiş (sistem dışı)
     * uygulamaları döndürür. Bu liste "şu an çalışan işlemler" değildir -
     * Android 5.1'den beri üçüncü parti uygulamalar başka uygulamaların canlı
     * işlem listesini göremez (gizlilik kısıtlaması). Bu yüzden en yakın ve
     * dürüst yaklaşım "yakın zamanda kullanılan" uygulamaları göstermektir.
     */
    fun getRecentlyUsedApps(context: Context): List<AppEntry> {
        if (!hasUsageAccess(context)) return emptyList()

        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val start = end - (12 * 60 * 60 * 1000L)

        val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_BEST, start, end)
        val pm = context.packageManager

        return stats
            .filter { it.totalTimeInForeground > 0 && it.packageName != context.packageName }
            .sortedByDescending { it.lastTimeUsed }
            .mapNotNull { stat ->
                try {
                    val appInfo = pm.getApplicationInfo(stat.packageName, 0)
                    val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    if (isSystem) return@mapNotNull null
                    AppEntry(
                        packageName = stat.packageName,
                        label = pm.getApplicationLabel(appInfo).toString(),
                        lastUsedMillis = stat.lastTimeUsed,
                        isSystemApp = false
                    )
                } catch (e: PackageManager.NameNotFoundException) {
                    null
                }
            }
            .distinctBy { it.packageName }
            .take(30)
    }

    /**
     * Bir uygulamanın arka plan işlemlerini sonlandırmayı DENER.
     * Gerçekçi olmak gerekirse: Android'in kendi bellek yöneticisi zaten
     * gerektiğinde arka plan uygulamalarını kapatır; bu çağrı sadece
     * "cached" durumdaki süreçleri erken temizler, anlık RAM'i biraz
     * boşaltabilir ama kalıcı bir "FPS artışı" garanti etmez.
     */
    fun tryKillBackground(context: Context, packageName: String): Boolean {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            am.killBackgroundProcesses(packageName)
            true
        } catch (e: SecurityException) {
            false
        }
    }

    /**
     * Uygulamayı tam olarak durdurmak (force-stop) için Android güvenlik
     * politikası gereği kullanıcının elle onay vermesi gerekir; bu yüzden
     * doğrudan Ayarlar > Uygulama Bilgisi ekranına yönlendiriyoruz.
     */
    fun openAppInfo(context: Context, packageName: String) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        intent.data = Uri.parse("package:$packageName")
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(intent)
    }
}
