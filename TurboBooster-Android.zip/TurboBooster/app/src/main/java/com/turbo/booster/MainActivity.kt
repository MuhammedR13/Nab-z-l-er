package com.turbo.booster

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.turbo.booster.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TurboBoosterTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    RootScreen()
                }
            }
        }
    }
}

@Composable
fun RootScreen() {
    var selectedTab by remember { mutableStateOf(0) }

    Scaffold(
        containerColor = DarkBg,
        bottomBar = {
            NavigationBar(containerColor = CardBg) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Filled.Home, contentDescription = null) },
                    label = { Text("Panel") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Filled.Apps, contentDescription = null) },
                    label = { Text("Uygulamalar") }
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            when (selectedTab) {
                0 -> DashboardScreen()
                1 -> AppListScreen()
            }
        }
    }
}

@Composable
fun DashboardScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var stats by remember { mutableStateOf(SystemInfoUtils.getDeviceStats(context)) }
    var gameModeOn by remember { mutableStateOf(false) }
    var lastBoostFreedMb by remember { mutableStateOf<Long?>(null) }
    var isBoosting by remember { mutableStateOf(false) }

    // Ekran her görünür olduğunda istatistikleri tazele
    LaunchedEffect(Unit) {
        stats = SystemInfoUtils.getDeviceStats(context)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "TurboBooster",
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
        )
        Text(
            "Sahte sayı yok, gerçek optimizasyon",
            fontSize = 13.sp,
            color = TextSecondary,
            modifier = Modifier.padding(bottom = 20.dp)
        )

        // RAM kartı
        StatCard(
            title = "RAM Kullanımı",
            valueText = "%${stats.memory.usedPercent}",
            subText = "${stats.memory.usedMb} MB / ${stats.memory.totalMb} MB kullanılıyor",
            accent = if (stats.memory.usedPercent > 80) DangerRed else BoostGreen,
            progress = stats.memory.usedPercent / 100f
        )

        Spacer(Modifier.height(12.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MiniStatCard(
                modifier = Modifier.weight(1f),
                label = "Pil",
                value = if (stats.batteryPercent >= 0) "%${stats.batteryPercent}" else "—",
                sub = if (stats.isCharging) "Şarj oluyor" else "Şarjda değil"
            )
            MiniStatCard(
                modifier = Modifier.weight(1f),
                label = "CPU Çekirdek",
                value = "${stats.cpuCores}",
                sub = "mantıksal çekirdek"
            )
        }

        Spacer(Modifier.height(24.dp))

        Button(
            onClick = {
                isBoosting = true
                val before = SystemInfoUtils.getMemoryStats(context).availMb
                val apps = AppUsageUtils.getRecentlyUsedApps(context)
                apps.forEach { AppUsageUtils.tryKillBackground(context, it.packageName) }
                System.gc()
                stats = SystemInfoUtils.getDeviceStats(context)
                val after = stats.memory.availMb
                lastBoostFreedMb = (after - before).coerceAtLeast(0)
                isBoosting = false
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = BoostGreen)
        ) {
            Text(
                if (isBoosting) "Temizleniyor..." else "Şimdi Hızlandır",
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                color = Color.Black
            )
        }

        lastBoostFreedMb?.let {
            Text(
                "Son temizlikte tahmini ${it} MB boşaltıldı. " +
                    "Not: Bu, RAM'i anlık boşaltır; GPU/CPU'yu büyüsel biçimde hızlandırmaz.",
                fontSize = 12.sp,
                color = TextSecondary,
                modifier = Modifier.padding(top = 10.dp)
            )
        }

        Spacer(Modifier.height(28.dp))

        Divider(color = Color(0xFF2A303B))
        Spacer(Modifier.height(20.dp))

        Text(
            "Oyun Modu",
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextPrimary,
            modifier = Modifier.align(Alignment.Start)
        )
        Text(
            "Bildirimleri sessize alır, ekranı uyanık tutar",
            fontSize = 12.sp,
            color = TextSecondary,
            modifier = Modifier.align(Alignment.Start).padding(bottom = 12.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardBg),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        if (gameModeOn) "Aktif" else "Kapalı",
                        color = if (gameModeOn) BoostGreen else TextSecondary,
                        fontWeight = FontWeight.Bold
                    )
                    if (!DndHelper.hasDndAccess(context)) {
                        Text(
                            "Bildirim erişim izni gerekli",
                            fontSize = 11.sp,
                            color = AccentOrange
                        )
                    }
                }
                Switch(
                    checked = gameModeOn,
                    onCheckedChange = { checked ->
                        if (checked && !DndHelper.hasDndAccess(context)) {
                            DndHelper.openDndSettings(context)
                            return@Switch
                        }
                        gameModeOn = checked
                        val intent = Intent(context, GameModeService::class.java)
                        if (checked) {
                            intent.action = null
                            context.startForegroundService(intent)
                        } else {
                            intent.action = GameModeService.ACTION_STOP
                            context.startService(intent)
                        }
                    },
                    colors = SwitchDefaults.colors(checkedThumbColor = BoostGreen)
                )
            }
        }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun StatCard(
    title: String,
    valueText: String,
    subText: String,
    accent: Color,
    progress: Float
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.padding(20.dp)) {
            Text(title, color = TextSecondary, fontSize = 13.sp)
            Spacer(Modifier.height(4.dp))
            Text(valueText, color = accent, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(
                progress = progress.coerceIn(0f, 1f),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = accent,
                trackColor = Color(0xFF2A303B)
            )
            Spacer(Modifier.height(8.dp))
            Text(subText, color = TextSecondary, fontSize = 12.sp)
        }
    }
}

@Composable
fun MiniStatCard(modifier: Modifier = Modifier, label: String, value: String, sub: String) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(label, color = TextSecondary, fontSize = 12.sp)
            Text(value, color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(sub, color = TextSecondary, fontSize = 11.sp)
        }
    }
}

@Composable
fun AppListScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var hasAccess by remember { mutableStateOf(AppUsageUtils.hasUsageAccess(context)) }
    var apps by remember { mutableStateOf(listOf<AppEntry>()) }

    LaunchedEffect(hasAccess) {
        if (hasAccess) apps = AppUsageUtils.getRecentlyUsedApps(context)
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            "Yakın Zamanda Kullanılan Uygulamalar",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
        Text(
            "Android gizlilik kısıtlaması nedeniyle uygulamalar başka " +
                "uygulamaların canlı süreç listesini göremez; bu liste son " +
                "12 saatteki kullanım verisine dayanır.",
            fontSize = 12.sp,
            color = TextSecondary,
            modifier = Modifier.padding(top = 6.dp, bottom = 16.dp)
        )

        if (!hasAccess) {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(20.dp)) {
                    Text(
                        "Bu listeyi görmek için Kullanım Erişimi izni gerekiyor.",
                        color = TextPrimary
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            AppUsageUtils.openUsageAccessSettings(context)
                            hasAccess = AppUsageUtils.hasUsageAccess(context)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BoostGreen)
                    ) {
                        Text("İzin Ver", color = Color.Black)
                    }
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(apps) { app ->
                    AppRow(app, onKill = {
                        AppUsageUtils.tryKillBackground(context, app.packageName)
                    }, onOpenInfo = {
                        AppUsageUtils.openAppInfo(context, app.packageName)
                    })
                }
            }
        }
    }
}

@Composable
fun AppRow(app: AppEntry, onKill: () -> Unit, onOpenInfo: () -> Unit) {
    val sdf = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    Card(
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(app.label, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                Text(
                    "Son kullanım: ${sdf.format(Date(app.lastUsedMillis))}",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
            TextButton(onClick = onKill) {
                Text("Kapat", color = AccentOrange, fontSize = 12.sp)
            }
            TextButton(onClick = onOpenInfo) {
                Text("Detay", color = TextSecondary, fontSize = 12.sp)
            }
        }
    }
}
