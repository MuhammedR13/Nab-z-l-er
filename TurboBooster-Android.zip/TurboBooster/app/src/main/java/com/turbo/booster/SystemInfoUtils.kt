package com.turbo.booster

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build

data class MemoryStats(
    val totalMb: Long,
    val availMb: Long,
    val usedMb: Long,
    val usedPercent: Int,
    val isLowMemory: Boolean
)

data class DeviceStats(
    val memory: MemoryStats,
    val batteryPercent: Int,
    val isCharging: Boolean,
    val cpuCores: Int
)

object SystemInfoUtils {

    fun getMemoryStats(context: Context): MemoryStats {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)

        val totalMb = info.totalMem / (1024 * 1024)
        val availMb = info.availMem / (1024 * 1024)
        val usedMb = totalMb - availMb
        val usedPercent = if (totalMb > 0) ((usedMb * 100) / totalMb).toInt() else 0

        return MemoryStats(
            totalMb = totalMb,
            availMb = availMb,
            usedMb = usedMb,
            usedPercent = usedPercent,
            isLowMemory = info.lowMemory
        )
    }

    fun getBatteryPercent(context: Context): Pair<Int, Boolean> {
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryStatus = context.registerReceiver(null, filter)
        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else -1

        val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

        return Pair(pct, charging)
    }

    fun getDeviceStats(context: Context): DeviceStats {
        val (batteryPct, charging) = getBatteryPercent(context)
        return DeviceStats(
            memory = getMemoryStats(context),
            batteryPercent = batteryPct,
            isCharging = charging,
            cpuCores = Runtime.getRuntime().availableProcessors()
        )
    }
}
