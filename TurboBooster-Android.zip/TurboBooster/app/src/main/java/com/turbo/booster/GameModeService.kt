package com.turbo.booster

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/**
 * Oyun Modu açıkken çalışan servis:
 *  - Ekranın kararmasını engeller (gerçek WakeLock, oyun sırasında ekranın
 *    kilitlenip performans kaybına/kesintiye yol açmasını önler)
 *  - Rahatsız Etme modunu açık tutar (bildirim popup'larının oyunu
 *    kesmesini / arka planda CPU harcamasını azaltır)
 *
 * Bu servis "FPS'i büyüsel şekilde artırmaz" - amacı kesintileri ve
 * gereksiz arka plan aktivitesini azaltmaktır, ki bunun gerçek ölçülebilir
 * bir etkisi vardır.
 */
class GameModeService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null

    companion object {
        const val CHANNEL_ID = "game_mode_channel"
        const val NOTIF_ID = 42
        const val ACTION_STOP = "com.turbo.booster.STOP_GAME_MODE"
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopGameMode()
            return START_NOT_STICKY
        }

        startForeground(NOTIF_ID, buildNotification())

        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ON_AFTER_RELEASE,
            "TurboBooster:GameModeWakeLock"
        )
        wakeLock?.setReferenceCounted(false)
        wakeLock?.acquire(4 * 60 * 60 * 1000L) // güvenlik için maksimum 4 saat

        DndHelper.setDnd(this, true)

        return START_STICKY
    }

    private fun stopGameMode() {
        wakeLock?.let { if (it.isHeld) it.release() }
        DndHelper.setDnd(this, false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Oyun Modu",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, GameModeService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Oyun Modu Aktif")
            .setContentText("Bildirimler sessizde, ekran uyumuyor")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(android.R.drawable.ic_media_pause, "Kapat", stopPending)
            .setOngoing(true)
            .build()
    }
}
